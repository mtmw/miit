1.click install.bat
2.press anykey to continue